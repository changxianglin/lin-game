flappy-bird
===========

Flappy Bird (Skin) Browser Game Phaser framework

Demo url: http://uralozden.com/flappy/

This repo is a fork of : Don't Touch My Birdie  https://github.com/marksteve/dtmb

His demo: http://marksteve.com/dtmb
