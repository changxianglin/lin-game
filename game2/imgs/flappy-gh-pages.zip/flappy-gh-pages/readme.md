#HTML5 flappy bird

play here: http://hyspace.io/flappy/

based on http://uralozden.com/flappy/

##License

MIT License

##Copyright

THE IMAGES' AND SOUNDS' COPYRIGHT IS OWNED BY THE ORIGINAL GAME'S AUTHOR.